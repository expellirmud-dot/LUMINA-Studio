# Handoff to Web AI

Do not redesign the website.

Use the selected images only to test:

1. Hero suitability
2. Story rhythm
3. Gallery sequence
4. Homepage image strength
5. Repeated visual patterns

Current layout is a photo testing room.

Do not decide permanent layout, motion, or structure.

## Selected Sets

## Hero Candidate

## Hero Sequence

## Gallery Sequence

## Observed Patterns

## Layout Problems Noted Only
