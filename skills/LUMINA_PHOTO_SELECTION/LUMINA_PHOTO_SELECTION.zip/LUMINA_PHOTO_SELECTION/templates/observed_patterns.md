# Observed Patterns

## Event Name

## Strongest Image Type

## Hero Pattern

## Homepage Pattern

## Emotional Anchor Pattern

## Supporting Image Pattern

## Images That Did Not Work

## Image Problem vs Layout Problem

## Notes for Future LUMINA Website Decisions
