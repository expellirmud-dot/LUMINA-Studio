---
name: LUMINA_PHOTO_SELECTION
description: Use this skill when selecting, sequencing, and organizing real photography sets for LUMINA Studio website, portfolio, homepage, hero sequence, web gallery, or final delivery. Focus on story, emotional impact, visual rhythm, filename accuracy, and image roles. Do not redesign the website.
---

# LUMINA Photo Selection Skill

## Purpose
This skill helps AI select real photography images for LUMINA Studio.

The goal is not to select isolated beautiful images. The goal is to build a coherent story set from one real event, using the perspective of a photographer, photo editor, and visual storyteller.

LUMINA gives priority to images that make viewers stop and feel something, rather than images that only look expensive, polished, or distant.

The current website layout is only a photo testing room. It is not a final design decision. During photo selection, do not redesign the website, hero layout, motion system, or permanent structure.

## Core Rule
Select for story, emotion, timing, rhythm, and usefulness.

Do not select only by technical beauty. Do not mix unrelated events into one story set. Do not guess filenames from contact sheet numbers. Always use `inventory.csv` as the source of truth for real filenames and paths.

## Read First
Before selecting images, read or inspect:

1. User’s goal for the selection.
2. Contact sheet, screenshots, or image previews.
3. `inventory.csv`, if available.
4. Source image folder, if available.
5. Existing selected folders, if available.
6. Category names such as Preparation, Procession, Ceremony, Portraits, Monk, Family, Detail, Venue.
7. Target output size such as `final_40`, `web_20`, or `homepage_8`.
8. Current website constraints.
9. Extra reference files under `references/` only when needed.
10. Output templates under `templates/` only when producing handoff artifacts.

If the contact sheet number and the actual file number do not match, trust `inventory.csv`.

## Required Inputs
Expected inputs may include contact sheet or screenshot set, `inventory.csv`, source image folder, image category labels, requested selection count, intended use, and current website notes or constraints.

## Inventory Rule
`inventory.csv` is the filename authority.

When reporting selected images, output real filename and path from `inventory.csv`. Never output a filename based only on a visible number on a contact sheet. If mapping is uncertain, mark the image as `needs_filename_verification`.

Use `scripts/validate_inventory.py` when a real CSV file is available and filename accuracy matters.

## Selection Levels
### final_40
A broad final set for archive, client delivery, backup, and website experiments. It should cover the full event, preserve important moments, include strong alternates, and support later web and portfolio decisions.

### web_20
A concise story set for website gallery or portfolio presentation. It should tell the event clearly, remove repetition, maintain rhythm, and balance context, people, ceremony, details, and closing.

### homepage_8
The strongest image set for homepage, hero, and featured sections. It should represent the event quickly, create immediate visual impact, show the LUMINA visual identity, and support hero/featured sections.

## Selection Principles
Read `references/SELECTION_PRINCIPLES.md` when selection quality or editorial judgment is central.

1. Select images that tell the story.
2. Prefer real emotion, meaningful timing, and clean visual attention.
3. Include opening, context, detail, emotion, key ritual, important people, transition, and closing images.
4. Avoid too many near-duplicates.
5. If images are similar, choose the one with stronger emotion, better timing, cleaner composition, and clearer subject.
6. Do not overvalue technically clean images if they feel empty.
7. Do not select images that look impressive but do not support the story.
8. Do not mix different events into one story set.
9. One image set should clearly represent one real event.
10. Balance wide, medium, close, detail, movement, and stillness.

## Reject Criteria
Read `references/REJECT_CRITERIA.md` when deciding what to remove.

Reject or deprioritize images with weak focus, awkward expression, broken timing, repeated frame with no added value, unclear subject, distracting clutter, severe exposure/color problems, technical cleanliness without story, mood mismatch, or visual strength that belongs to another story.

## Story Order
Read `references/STORY_PATTERNS.md` when the event type needs a specific narrative pattern.

Default story order:
1. Opening / Establishing
2. Preparation
3. Movement / Procession
4. Key Ritual
5. Emotion / Family Connection
6. Ceremony / Transition
7. Portrait / Confirmation
8. Closing Image

Adjust the order to fit the actual event. Do not simply sort by filename unless the filename order also supports the story.

## Website Roles
Read `references/WEBSITE_ROLES.md` when assigning use on the website.

Assign one or more roles: Hero, Hero sequence, Featured image, Story grid, Detail image, Transition image, Emotional anchor, Ceremony image, Context image, Portrait / Confirmation, Closing image.

A strong image may have multiple roles, but avoid assigning every image as Hero.

## Current Website Constraint
Do not redesign the website. Do not decide permanent hero, layout, motion, or structure. Treat the current hero and layout as a testing room for photography.

Focus only on image selection, story sequence, website role assignment, visual rhythm, observed patterns, and filename accuracy. If layout problems appear, record them as notes only.

## Pattern Observation
After each selection, record observed patterns for future LUMINA website decisions:

- which image types repeatedly work as hero
- which images make viewers stop
- which images work best for homepage
- whether the event is strongest in ritual, people, emotion, light, crowd, or detail
- whether the image set fits the current website
- whether any problem comes from the image set rather than layout
- which images are better as support rather than hero
- which visual direction appears repeatedly across multiple events

## Required Output
For each selection, provide event visual summary, selected filenames from `inventory.csv`, `final_40` / `web_20` / `homepage_8` if requested, website roles, story order, reasons for key images, rejected patterns or duplicate groups, filename verification notes, and observed patterns.

## Preferred Output Format
Use JSON when the result will be passed to another AI, script, or website workflow. Use `templates/selection_output.schema.json` as the structure.

## Quality Bar
A good selection should feel like one real event. It should have rhythm. It should not feel like a folder of unrelated good images. It should make the viewer understand what happened, who mattered, what the emotional center was, and why the event was worth remembering.

## Stop Conditions
Stop and ask for clarification only if there is no `inventory.csv` and filenames are required, images from multiple events are mixed and cannot be separated, target output size is impossible, or contact sheet numbers cannot be mapped to real files.

If the task can still proceed, make the best possible selection and clearly mark uncertain items.
