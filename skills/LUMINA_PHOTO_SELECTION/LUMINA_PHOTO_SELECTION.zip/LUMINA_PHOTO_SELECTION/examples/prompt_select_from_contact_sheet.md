# Prompt: Select Images from Contact Sheet

ใช้สกิล LUMINA_PHOTO_SELECTION

เป้าหมาย: คัดภาพจากงานนี้เป็น final_40, web_20, homepage_8

ให้อ่าน contact sheet และ inventory.csv
ยึด inventory.csv เป็น source of truth สำหรับ filename/path
ห้ามเดาชื่อไฟล์จากเลขบน contact sheet
ห้าม redesign เว็บไซต์

ให้คัดแบบช่างภาพ/บรรณาธิการภาพ โดยเน้น story, emotion, timing, rhythm และ website roles

Output:
- JSON ตาม templates/selection_output.schema.json
- สรุปรายงานสั้นแบบมนุษย์อ่านง่าย
- observed_patterns สำหรับสะสมบทเรียน LUMINA
