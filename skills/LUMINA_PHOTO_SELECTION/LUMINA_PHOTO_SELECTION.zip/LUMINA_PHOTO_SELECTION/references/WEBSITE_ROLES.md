# LUMINA Website Roles

Assign roles based on how the image works inside a website sequence. Do not redesign the website while assigning roles.

## Hero
The strongest single image. It must stop attention quickly and represent the event's emotional center. Good hero traits: immediate feeling, clear subject, strong mood, low clutter, works at large size, and not dependent on a long caption.

## Hero Sequence
A short set of images that can rotate or sequence without repeating the same feeling. A good hero sequence often includes emotional anchor, context, action or ritual, and quiet closing or confirmation.

## Featured Image
Strong enough to represent the event in cards, sections, or previews, but not always the main hero.

## Story Grid
Images that support narrative flow. They may not be the strongest alone, but they make the set complete.

## Detail Image
Small visual evidence that adds texture and realism, such as hands, objects, fabric, ritual detail, food, light, or signage.

## Transition Image
Images that move the story between phases, such as walking, turning, entering, leaving, preparation before ceremony, or quiet moment after peak action.

## Emotional Anchor
The image that carries the emotional memory of the event. It can be hero, homepage, or gallery centerpiece.

## Closing Image
A calm, resolved, or confirming image that ends the story. Good closing images often feel complete rather than loud.
