# LUMINA Reject Criteria

Reject or deprioritize images that weaken the story set.

## Technical Rejects
- focus failure that damages the feeling
- severe exposure or color problems that are difficult to recover
- motion blur that is not emotionally or visually intentional
- file or preview quality too weak for intended use

## Human Timing Rejects
- awkward facial expression from the main subject
- closed eyes from the main subject, unless emotionally intentional
- broken gesture or half-moment
- unflattering angle that distracts from the story

## Story Rejects
- repeated frame with no added value
- unclear subject
- strong isolated frame that does not belong in the set
- mood mismatch
- image that duplicates another stronger image
- image that makes the set feel like mixed events

## Web Rejects
- too cluttered for hero
- too visually weak for homepage
- too dependent on caption
- unsuitable crop for the intended role
- damages visual rhythm of the sequence
