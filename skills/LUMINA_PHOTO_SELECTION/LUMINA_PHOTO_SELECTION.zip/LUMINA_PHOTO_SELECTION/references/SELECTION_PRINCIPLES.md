# LUMINA Selection Principles

LUMINA photo selection is editorial, not decorative. The selection must build a coherent story set from one real event.

## Prioritize
1. Story clarity
2. Real emotion
3. Human presence
4. Meaningful timing
5. Clean visual attention
6. Event completeness
7. Website usefulness
8. Visual rhythm across the full set
9. Images that make viewers stop
10. Images that carry memory, not only surface polish

## Deprioritize
1. Luxury look without feeling
2. Technical perfection without story
3. Repetition
4. Random beautiful frames
5. Images that break the event mood
6. Frames that are strong alone but weak in the sequence
7. Overly posed images that feel disconnected from the event

## Editorial Tie-breakers
When choosing between two similar images, prefer the one with more truthful emotion, clearer subject, better timing, cleaner background, stronger relationship between people, stronger story position, and better fit with surrounding images.

## LUMINA Sentence
LUMINA gives priority to images that people want to stop and look at, rather than images that look expensive but feel distant.
