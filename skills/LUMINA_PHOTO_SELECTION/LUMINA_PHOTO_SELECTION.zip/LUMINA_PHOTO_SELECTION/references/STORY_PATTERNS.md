# LUMINA Story Patterns

Use story order as a narrative tool. Do not simply sort by filename unless the filename order also supports the emotional story.

## Default Story Order
Opening / Establishing → Preparation → Movement / Procession → Key Ritual → Emotion / Family Connection → Ceremony / Transition → Portrait / Confirmation → Closing Image

## Ordination
Preparation → Procession → Bathing → Ceremony → Family Portrait → Monk Transition → Closing

Notes: the strongest hero may be emotional, not necessarily ceremonial. Family portrait is often better as confirmation or closing than hero. Monk transition images can be strong closing frames.

## Wedding
Venue → Couple → Family → Guests → Ceremony → Emotion → Celebration → Closing

Notes: avoid overusing posed couple frames. Look for small emotional gestures. Use venue and detail images to create breathing space.

## Municipal / Public Event
Venue / Context → Officials / Opening → Activity → People → Detail → Group / Confirmation → Closing

Notes: do not make the set look like a documentation dump. Balance officials with public participation. Prefer images that show service, interaction, and community benefit.

## Concert / Stage
Venue → Crowd → Performer → Peak Moment → Reaction → Detail → Closing

Notes: use crowd reaction to prove energy. Peak performance is not always the best hero if the emotional anchor is elsewhere.

## General Event / Party
Venue → Arrival → People → Activity → Peak Moment → Reaction → Group / Closing
