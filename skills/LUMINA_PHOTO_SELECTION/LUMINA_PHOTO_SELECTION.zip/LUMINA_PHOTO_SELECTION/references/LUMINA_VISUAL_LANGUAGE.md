# LUMINA Visual Language

LUMINA prefers real moments, quiet emotional weight, human warmth, clean but not sterile composition, editorial rhythm, and images that feel observed rather than staged.

## Prefer
- real moments
- quiet emotional weight
- human warmth
- story clarity
- clean but not sterile composition
- editorial rhythm
- images that feel observed, not staged
- beauty that supports memory

## Avoid
- over-polished emptiness
- fake luxury
- excessive posing
- generic stock-photo feeling
- website decoration before event understanding
- selecting images only because they look expensive

## Brand Direction
LUMINA should feel modern, calm, human, and editorial. It should not feel like generic luxury or a template portfolio.
