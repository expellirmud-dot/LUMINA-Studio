#!/usr/bin/env python3
"""Lightweight near-duplicate warning helper for LUMINA selections.

This does not inspect image pixels. It groups neighboring filenames/image IDs so an AI or editor can review possible bursts.
"""
from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path


def trailing_number(text: str) -> int | None:
    matches = re.findall(r"(\d+)", text)
    return int(matches[-1]) if matches else None


def main() -> int:
    parser = argparse.ArgumentParser(description="Find possible duplicate/burst groups from inventory.csv")
    parser.add_argument("inventory_csv")
    parser.add_argument("--gap", type=int, default=2, help="numeric gap considered near duplicate")
    args = parser.parse_args()

    path = Path(args.inventory_csv)
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))

    items = []
    for row in rows:
        label = row.get("filename") or row.get("image_id") or ""
        n = trailing_number(label)
        if n is not None:
            items.append((n, row))

    items.sort(key=lambda x: x[0])
    groups = []
    current = []
    prev = None
    for n, row in items:
        if prev is None or n - prev <= args.gap:
            current.append(row)
        else:
            if len(current) > 1:
                groups.append(current)
            current = [row]
        prev = n
    if len(current) > 1:
        groups.append(current)

    print(f"possible_duplicate_groups: {len(groups)}")
    for i, group in enumerate(groups[:50], 1):
        labels = [g.get("filename") or g.get("image_id") for g in group]
        print(f"group_{i}: {labels}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
