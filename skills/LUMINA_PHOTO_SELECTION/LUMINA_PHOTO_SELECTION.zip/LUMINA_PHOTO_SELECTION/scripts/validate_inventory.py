#!/usr/bin/env python3
"""Validate a LUMINA inventory.csv file.

Expected useful columns: image_id, filename, path.
The script is intentionally conservative: it reports issues but does not modify files.
"""
from __future__ import annotations

import argparse
import csv
from collections import Counter
from pathlib import Path

REQUIRED = ["image_id", "filename", "path"]


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate LUMINA inventory.csv")
    parser.add_argument("inventory_csv", help="Path to inventory.csv")
    args = parser.parse_args()

    path = Path(args.inventory_csv)
    if not path.exists():
        print(f"ERROR: file not found: {path}")
        return 2

    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
        fields = reader.fieldnames or []

    missing = [c for c in REQUIRED if c not in fields]
    print(f"inventory_csv: {path}")
    print(f"rows: {len(rows)}")
    print(f"columns: {fields}")

    if missing:
        print(f"ERROR: missing required columns: {missing}")
        return 1

    ids = [r.get("image_id", "").strip() for r in rows]
    filenames = [r.get("filename", "").strip() for r in rows]
    paths = [r.get("path", "").strip() for r in rows]

    duplicate_ids = [k for k, v in Counter(ids).items() if k and v > 1]
    empty_ids = sum(1 for x in ids if not x)
    empty_filenames = sum(1 for x in filenames if not x)
    empty_paths = sum(1 for x in paths if not x)

    print(f"empty_image_id: {empty_ids}")
    print(f"empty_filename: {empty_filenames}")
    print(f"empty_path: {empty_paths}")
    print(f"duplicate_image_id_count: {len(duplicate_ids)}")
    if duplicate_ids:
        print("duplicate_image_id_sample:", duplicate_ids[:20])

    if duplicate_ids or empty_ids or empty_filenames:
        print("STATUS: NEEDS_REVIEW")
        return 1

    print("STATUS: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
