#!/usr/bin/env python3
"""Build final_selection.json by mapping selected image_id values to filenames/paths.

Input selection file format:
{
  "project": "event-name",
  "final_40": ["001", "002"],
  "web_20": ["001"],
  "homepage_8": ["002"]
}
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def load_inventory(path: Path) -> dict[str, dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    return {str(r.get("image_id", "")).strip(): r for r in rows if str(r.get("image_id", "")).strip()}


def map_ids(ids: list, inventory: dict[str, dict]) -> list[dict]:
    out = []
    for image_id in ids:
        key = str(image_id).strip()
        row = inventory.get(key)
        if not row:
            out.append({"image_id": key, "filename": "", "path": "", "status": "needs_filename_verification"})
            continue
        out.append({
            "image_id": key,
            "filename": row.get("filename", ""),
            "path": row.get("path", ""),
            "status": "ok",
        })
    return out


def main() -> int:
    parser = argparse.ArgumentParser(description="Build LUMINA selection JSON from selected image IDs")
    parser.add_argument("inventory_csv")
    parser.add_argument("selection_ids_json")
    parser.add_argument("-o", "--output", default="final_selection.json")
    args = parser.parse_args()

    inventory = load_inventory(Path(args.inventory_csv))
    data = json.loads(Path(args.selection_ids_json).read_text(encoding="utf-8"))

    result = {
        "project": data.get("project", ""),
        "source": {"inventory_csv": str(Path(args.inventory_csv))},
        "final_40": map_ids(data.get("final_40", []), inventory),
        "web_20": map_ids(data.get("web_20", []), inventory),
        "homepage_8": map_ids(data.get("homepage_8", []), inventory),
        "filename_verification_notes": [],
    }

    for level in ["final_40", "web_20", "homepage_8"]:
        missing = [x["image_id"] for x in result[level] if x["status"] != "ok"]
        if missing:
            result["filename_verification_notes"].append({"level": level, "missing_image_ids": missing})

    Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"wrote: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
