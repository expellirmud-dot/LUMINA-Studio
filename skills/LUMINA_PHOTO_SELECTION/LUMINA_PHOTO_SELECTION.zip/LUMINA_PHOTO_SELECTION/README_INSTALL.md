# LUMINA_PHOTO_SELECTION Installation

Target path requested:

```powershell
D:\lumina-photo-harvest\LUMINA_PHOTO_SELECTION
```

## Install from zip

1. Download `LUMINA_PHOTO_SELECTION.zip`.
2. Extract it to:

```powershell
D:\lumina-photo-harvest\LUMINA_PHOTO_SELECTION
```

If the zip extracts as a nested folder, the final structure should be:

```text
D:\lumina-photo-harvest\LUMINA_PHOTO_SELECTION\SKILL.md
D:\lumina-photo-harvest\LUMINA_PHOTO_SELECTION\references\...
D:\lumina-photo-harvest\LUMINA_PHOTO_SELECTION\templates\...
D:\lumina-photo-harvest\LUMINA_PHOTO_SELECTION\scripts\...
```

## PowerShell create/extract command

```powershell
New-Item -ItemType Directory -Force "D:\lumina-photo-harvest" | Out-Null
Expand-Archive -Path "$env:USERPROFILE\Downloads\LUMINA_PHOTO_SELECTION.zip" -DestinationPath "D:\lumina-photo-harvest" -Force
```

## Validate inventory

```powershell
python "D:\lumina-photo-harvest\LUMINA_PHOTO_SELECTION\scripts\validate_inventory.py" "D:\path\to\inventory.csv"
```

## Build selection JSON

```powershell
python "D:\lumina-photo-harvest\LUMINA_PHOTO_SELECTION\scripts\build_selection_json.py" "D:\path\to\inventory.csv" "D:\path\to\selection_ids.json" -o "D:\path\to\final_selection.json"
```
